#ifndef LAB10_11_WASHLISTGUI_H
#define LAB10_11_WASHLISTGUI_H

#include <QWidget>
#include <QtWidgets>
#include "Service.h"


class WashListGUI : public QWidget, public Observer {
private:
    Service& srv;

    QPushButton* wl_new_button;
    QPushButton* wl_add_button;
    QPushButton* wl_clear_button;
    QPushButton* wl_priority_button;
    QPushButton* wl_export_button;

    QListWidget* q_wash_list;

    void init_GUI();
    void connect_buttons();
    void refresh_wash_list(const vector<Car>& car_list);

    void update() override {
        refresh_wash_list(srv.get_all_wash_list());
    }

public:
    WashListGUI(Service& srv) : srv { srv } {
        init_GUI();
        connect_buttons();
        refresh_wash_list(srv.get_all_wash_list());
    };

};

class WashListReadOnlyGUI : public QWidget, public Observer {
private:
    Service& srv;

    void paintEvent(QPaintEvent*) override {
        QPainter p{ this };
        int x = 0;
        int y = 0;
        for (auto song : srv.get_all_wash_list()) {
            //p.drawRect(x, y, 10, song.getDurata() * 10);
            x= rand() % 400 + 1;
            y = rand() % 400 + 1;
            qDebug() << x << " " << y;
            QRectF target(x, y, 100, 94);
            QRectF source(0, 0, 732, 720);
            QImage image("sun.jpg");

            p.drawImage(target,image, source);

            x += 40;

        }
    }
    void update() override {
        repaint();
    }

public:
    WashListReadOnlyGUI(Service& srv) : srv { srv } {
        srv.get_wash_list().addObserver(this);
    };

};

#endif //LAB10_11_WASHLISTGUI_H
